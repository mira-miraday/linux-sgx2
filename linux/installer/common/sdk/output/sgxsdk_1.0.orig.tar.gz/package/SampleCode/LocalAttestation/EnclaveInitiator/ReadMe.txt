==================================================================================================
                Dynamic Link Library : Enclave1 Project Overview
==================================================================================================

Enclave Project Wizard has created this Enclave1 project for you as a starting point.

This file contains a summary of what you will find in each of the files that make up your project.

Enclave1.vcxproj
    This is the main project file for projects generated using an Enclave Wizard. 
    It contains information about the version of the product that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Enclave Wizard.

Enclave1.vcxproj.filters
    This is the filters file for VC++ projects generated using an Enclave Wizard. 
    It contains information about the association between the files in your project 
    and the filters. This association is used in the IDE to show grouping of files with
    similar extensions under a specific node (for e.g. ".cpp" files are associated with the
    "Source Files" filter).

